Create `.env` in root dir with

```
NEXT_PUBLIC_ALCHEMY_API_KEY= ...
NEXT_PUBLIC_PAYMASTER_POLICY_ID= ...
```

Then

`yarn install`

`yarn dev`