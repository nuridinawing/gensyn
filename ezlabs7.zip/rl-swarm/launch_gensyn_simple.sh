#!/bin/bash

# Pastikan script akan keluar jika ada perintah yang gagal
set -euo pipefail

# --- Konfigurasi Awal ---
# ROOT akan menjadi direktori Gensyn RL Swarm (misal: /root/rl-swarm)
# Skrip ini (launch_gensyn_simple.sh) harus berada di direktori ini juga.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Path ke virtual environment Anda
VENV_PATH="$ROOT/.venv/bin/activate"

# Path ke direktori sumber file yang akan disalin (dari ezlabs)
SOURCE_EZLABS_DIR="/root/ezlabs/"
# Direktori tujuan untuk userApiKey.json dan userData.json
DEST_MODAL_DATA_DIR="$ROOT/modal-login/temp-data/"
# Direktori tujuan untuk swarm.pem
DEST_ROOT_DIR="$ROOT/"

# Otomatisasi Prompt Hugging Face Hub (Set ke "None" untuk tidak push)
export HUGGINGFACE_ACCESS_TOKEN="None"

# Otomatisasi Prompt Nama Model: Langsung tentukan model yang akan digunakan
AUTO_MODEL_NAME="Gensyn/Qwen2.5-0.5B-Instruct"
export MODEL_NAME="$AUTO_MODEL_NAME" # Ini akan diekspor untuk proses Python Gensyn

# Warna teks untuk output konsol
GREEN_TEXT="\033[32m"
BLUE_TEXT="\033[34m"
RED_TEXT="\033[31m"
RESET_TEXT="\033[0m"

echo_green() { echo -e "$GREEN_TEXT$1$RESET_TEXT"; }
echo_blue() { echo -e "$BLUE_TEXT$1$RESET_TEXT"; }
echo_red() { echo -e "$RED_TEXT$1$RESET_TEXT"; }

# --- Cleanup Function (Called by systemd on stop/restart) ---
cleanup() {
    echo_green ">> [Systemd Cleanup] Mematikan proses Gensyn..."
    # Hapus credentials modal jika ada
    rm -r "$ROOT"/modal-login/temp-data/*.json 2> /dev/null || true
    echo_green ">> [Systemd Cleanup] Proses Gensyn dimatikan."
}
# systemd akan mengirim sinyal SIGTERM, script akan keluar, lalu cleanup akan jalan.
# Trap EXIT ini untuk memastikan cleanup berjalan jika script ini dihentikan manual
trap cleanup EXIT

echo_green ">> Memulai Gensyn RL Swarm melalui launch_gensyn_simple.sh..."

# Aktifkan virtual environment
# Ini akan membuat perintah Python dan pip yang dijalankan setelah ini menggunakan venv
source "$VENV_PATH"

# --- Persiapan Modal Login (Penyalinan file) ---
echo_green ">> Menyiapkan file-file modal-login..."
mkdir -p "$DEST_MODAL_DATA_DIR" # Pastikan direktori tujuan ada

# Salin userApiKey.json dan userData.json
if [ -f "$SOURCE_EZLABS_DIR/userApiKey.json" ]; then
    cp -f "$SOURCE_EZLABS_DIR/userApiKey.json" "$DEST_MODAL_DATA_DIR"
    echo ">> userApiKey.json disalin."
else
    echo_red "WARNING: userApiKey.json tidak ditemukan di $SOURCE_EZLABS_DIR. Pastikan ini ada."
    # systemd akan merestart, tapi ini bisa jadi loop jika file benar-benar tidak ada.
    # Anda mungkin ingin exit 1 di sini jika keberadaan file ini kritis dan tidak ada cara lain.
fi

if [ -f "$SOURCE_EZLABS_DIR/userData.json" ]; then
    cp -f "$SOURCE_EZLABS_DIR/userData.json" "$DEST_MODAL_DATA_DIR"
    echo ">> userData.json disalin."
else
    echo_red "WARNING: userData.json tidak ditemukan di $SOURCE_EZLABS_DIR. Pastikan ini ada."
    # Anda mungkin ingin exit 1 di sini jika keberadaan file ini kritis dan tidak ada cara lain.
fi

# Salin swarm.pem
if [ -f "$SOURCE_EZLABS_DIR/swarm.pem" ]; then
    cp -f "$SOURCE_EZLABS_DIR/swarm.pem" "$DEST_ROOT_DIR"
    echo ">> swarm.pem disalin."
else
    echo_red "WARNING: swarm.pem tidak ditemukan di $SOURCE_EZLABS_DIR. Ini akan dibuat baru jika tidak ada."
fi

echo_green ">> File-file penting disiapkan."

# --- Bagian Modal Login Server (Hanya dijalankan jika dibutuhkan) ---
# Jika server modal-login Anda sudah berjalan sebagai systemd service terpisah,
# atau jika Gensyn RL Swarm menanganinya secara internal tanpa loop di script ini,
# maka bagian ini mungkin tidak perlu seluruh kode start modal-login.
# Namun, karena ini ada di run_rl_swarm.sh asli, saya sertakan secara minimal
# untuk memastikan environment Node.js/Yarn dan localtunnel disiapkan.

# Catatan: Ini adalah bagian kompleks dari Gensyn asli.
# Idealnya, modal-login server berjalan sebagai systemd service terpisah
# jika itu adalah komponen yang terus berjalan dan tidak hanya sekali pakai.
# Untuk kesederhanaan, saya akan menghilangkan loop "Waiting for..." dan
# asumsi file sudah disalin secara otomatis dan API Key sudah aktif.

# Jika Anda perlu menjalankan server modal-login dan localtunnel dari sini:
# Anda perlu menambahkan logika `yarn start` dan `lt` di sini
# dan pastikan mereka tidak memblokir eksekusi Gensyn utama.
# Untuk tujuan systemd, kita asumsikan modal-login service sudah berjalan.

# Menunggu API key diaktifkan (tetap perlu ini)
# Ini penting agar Gensyn tidak mulai sebelum API key siap.
echo "Menunggu API key diaktifkan..."
# Ambil ORG_ID dari userData.json yang baru disalin
ORG_ID=$(awk 'BEGIN { FS = "\"" } !/^[ \t]*[{}]/ { print $(NF - 1); exit }' "$DEST_MODAL_DATA_DIR/userData.json")
export ORG_ID # Ekspor ORG_ID agar Gensyn Python bisa membacanya

# Tambahkan timeout agar tidak stuck tanpa batas
timeout 180s bash -c "while true; do STATUS=$(curl -s http://localhost:3000/api/get-api-key-status?orgId=${ORG_ID}); [[ \"\$STATUS\" == \"activated\" ]] && break; echo -n '.'; sleep 5; done" || { echo_red "ERROR: API key tidak aktif dalam 3 menit. Periksa server modal-login atau login secara manual."; exit 1; }
echo_green "API key telah diaktifkan! Melanjutkan..."


# --- Instalasi Dependensi Python (Pastikan sudah terinstal dari luar systemd) ---
# Idealnya, dependensi ini diinstal sekali secara manual, bukan setiap kali Gensyn restart.
# Jika Anda ingin ini diinstal setiap kali, unkomentari di bawah.
# echo_green ">> Mengambil dependensi Python..."
# pip install --upgrade pip
# echo_green ">> Menginstal paket Gensyn RL Swarm..."
# pip install gensyn-genrl==0.1.4
# pip install reasoning-gym>=0.1.20
# pip install trl
# pip install hivemind@git+https://github.com/gensyn-ai/hivemind@639c964a8019de63135a2594663b5bec8e5356dd

# --- Konfigurasi rg-swarm.yaml (Disalin hanya jika berbeda/tidak ada) ---
# Logika ini menjaga konfigurasi tetap up-to-date
if [ ! -d "$ROOT/configs" ]; then
    mkdir "$ROOT/configs"
fi  
if [ -f "$ROOT/configs/rg-swarm.yaml" ]; then
    if ! cmp -s "$ROOT/rgym_exp/config/rg-swarm.yaml" "$ROOT/configs/rg-swarm.yaml"; then
        echo_green ">> Ditemukan perbedaan di rg-swarm.yaml. Mencadangkan dan menyalin yang baru."
        mv "$ROOT/configs/rg-swarm.yaml" "$ROOT/configs/rg-swarm.yaml.bak" || true
        cp "$ROOT/rgym_exp/config/rg-swarm.yaml" "$ROOT/configs/rg-swarm.yaml"
    fi
else
    echo_green ">> Mengkopi rg-swarm.yaml default."
    cp "$ROOT/rgym_exp/config/rg-swarm.yaml" "$ROOT/configs/rg-swarm.yaml"
fi

echo_green ">> Selesai persiapan."

# --- Peluncuran Gensyn RL Swarm Utama ---
# Ini adalah satu-satunya perintah Gensyn yang akan dijalankan oleh systemd.
# Semua auto-restart ditangani oleh systemd.
echo_green ">> Meluncurkan rgym swarm launcher..."
python -m rgym_exp.runner.swarm_launcher \
    --config-path "$ROOT/rgym_exp/config" \
    --config-name "rg-swarm.yaml"

echo_green ">> rgym swarm launcher telah berhenti (systemd akan merestart jika dikonfigurasi)."