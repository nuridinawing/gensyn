import os
import multiprocessing
import logging
from typing import Optional

import hydra
from genrl.communication.communication import Communication
from genrl.communication.hivemind.hivemind_backend import (
    HivemindBackend,
    HivemindRendezvouz,
)
from hydra.utils import instantiate
from omegaconf import DictConfig, OmegaConf

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Force CPU-only mode
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

def configure_for_cpu(cfg: DictConfig) -> DictConfig:
    """Auto-configure for CPU with guaranteed participation"""
    total_cores = multiprocessing.cpu_count()
    usable_cores = max(1, total_cores - 1)  # Leave 1 core for OS

    # Dynamic scaling
    beam_size = max(4, min(16, total_cores))
    batch_size = max(1, min(2, total_cores // 4))  # Conservative scaling

    # Thread management
    for env_var in ["OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
        os.environ[env_var] = str(usable_cores)

    # Modify config
    cfg.game_manager.communication.beam_size = beam_size
    cfg.game_manager.communication.min_batch_size = 1  # Critical
    cfg.game_manager.communication.target_batch_size = 2
    cfg.game_manager.communication.compression = "none"

    if "trainer" in cfg.game_manager:
        cfg.game_manager.trainer.config.batch_size = batch_size
        cfg.game_manager.trainer.config.gradient_accumulation_steps = max(1, 4 // batch_size)

    logger.info(
        f"CPU Optimization | "
        f"Cores: {total_cores} | "
        f"Beam: {beam_size} | "
        f"Batch: {batch_size} | "
        f"Participation: 100%"
    )
    
    return cfg

@hydra.main(version_base=None)
def main(cfg: DictConfig):
    HivemindRendezvouz.init(is_master=False)
    cfg = configure_for_cpu(cfg)
    
    game_manager = instantiate(cfg.game_manager)
    game_manager.run_game()

if __name__ == "__main__":
    Communication.set_backend(HivemindBackend)
    main()