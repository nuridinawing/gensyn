import os
import torch
import hydra
from omegaconf import DictConfig
from hydra.utils import instantiate

# CPU Optimization
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

@hydra.main(version_base=None, config_path="../config", config_name="rg-swarm")
def main(cfg: DictConfig):
    # Additional CPU optimizations
    torch.set_num_threads(1)
    cfg.game_manager.trainer.models[0].torch_dtype = torch.float32
    
    game_manager = instantiate(cfg.game_manager)
    game_manager.run_game()

if __name__ == "__main__":
    main()